package menuClasses;

import java.io.IOException;

import ioManagementClasses.IOComponent;
import systemClasses.SystemController;

public class RemoveDocumentAction implements Action {

	@Override
	public void execute(Object args) {
		// TODO Auto-generated method stub

		SystemController sc = (SystemController) args; 
		IOComponent io = IOComponent.getComponent();
		io.output("\nAdding a new document to the index system:\n"); 
		String docName = io.getInput("\nEnter name of new document: ").trim(); 
		String statusMSG = null;
		try{
			statusMSG = ;// removerlo 
			io.output(statusMSG);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
